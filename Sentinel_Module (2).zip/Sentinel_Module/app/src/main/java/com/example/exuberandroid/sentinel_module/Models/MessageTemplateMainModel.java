package com.example.exuberandroid.sentinel_module.Models;

import java.util.ArrayList;

public class MessageTemplateMainModel {

    private ArrayList<MessageTemplateModel> messageTemplateModelArrayList;
    private String messageTemplateHeader;


    public MessageTemplateMainModel() {

    }


    public MessageTemplateMainModel(ArrayList<MessageTemplateModel> messageTemplateModelArrayList, String messageTemplateHeader) {
        this.messageTemplateModelArrayList = messageTemplateModelArrayList;
        this.messageTemplateHeader = messageTemplateHeader;
    }




    public ArrayList<MessageTemplateModel> getMessageTemplateModelArrayList() {
        return messageTemplateModelArrayList;
    }

    public void setMessageTemplateModelArrayList(ArrayList<MessageTemplateModel> messageTemplateModelArrayList) {
        this.messageTemplateModelArrayList = messageTemplateModelArrayList;
    }

    public String getMessageTemplateHeader() {
        return messageTemplateHeader;
    }

    public void setMessageTemplateHeader(String messageTemplateHeader) {
        this.messageTemplateHeader = messageTemplateHeader;
    }






}
