package com.example.exuberandroid.sentinel_module.Adapters;

import android.content.Context;
import android.support.annotation.IdRes;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Activities.MessageTemplateActivity;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateMainModel;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateModel;
import com.example.exuberandroid.sentinel_module.R;

import java.util.ArrayList;
import java.util.List;

public class MessageTemplateAdapter extends RecyclerView.Adapter<MessageTemplateAdapter.MyViewHolder> {

    List<MessageTemplateMainModel> adapterTemplateList = new ArrayList<>();
    private Context mContext;

    private int lastSelectedPosition = 1;



    public MessageTemplateAdapter(Context context, ArrayList<MessageTemplateMainModel> adapterTemplateList) {

        this.mContext=context;
        this.adapterTemplateList=adapterTemplateList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_message_temp,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {


        holder.text_temp_head.setText(adapterTemplateList.get(position).getMessageTemplateHeader());

        ArrayList<MessageTemplateModel> templateMessageList = adapterTemplateList.get(position).getMessageTemplateModelArrayList();


        MessageTemplateChildAdapter messageTemplateChildAdapter = new MessageTemplateChildAdapter(mContext,templateMessageList);
        holder.templateList.setAdapter(messageTemplateChildAdapter);
        messageTemplateChildAdapter.notifyDataSetChanged();


    }

    @Override
    public int getItemCount() {

        //Log.e("Message", String.valueOf(MsgTemp.size()));
        return adapterTemplateList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView text_temp_head;
        RecyclerView templateList;

        public MyViewHolder(final View itemView) {
            super(itemView);

            text_temp_head=(TextView)itemView.findViewById(R.id.text_temp_head);
            templateList = itemView.findViewById(R.id.messageTempList);

            LinearLayoutManager mLayoutManager = new LinearLayoutManager(mContext);
            templateList.setLayoutManager(mLayoutManager);
            templateList.hasFixedSize();

            }
    }


    public List<MessageTemplateMainModel> getTemplateList()
    {
        return  adapterTemplateList;
    }

}
