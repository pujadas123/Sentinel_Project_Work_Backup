package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Models.AlarmNewModel.AlarmModel;
import com.example.exuberandroid.sentinel_module.Models.AlarmNewModel.UpdatedBy;
import com.example.exuberandroid.sentinel_module.Models.alarmretromodel.AlarmOutput;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Api;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;

import org.json.JSONException;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitPutExample extends AppCompatActivity implements View.OnClickListener{

    EditText input_alarm,input_confirm_alarm;
    TextView doneBTN,msgBTN;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retro);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();


        input_alarm=(EditText)findViewById(R.id.input_alarm);

        input_confirm_alarm=(EditText)findViewById(R.id.input_confirm_alarm);

        doneBTN=(TextView)findViewById(R.id.doneBTN);
        doneBTN.setOnClickListener(this);

        msgBTN=(TextView)findViewById(R.id.msgBTN);
        msgBTN.setOnClickListener(this);


    }




    @Override
    public void onClick(View view) {
        if (Utilities.isOnline(this)) {
                    if (input_alarm.getText().toString().length() == 0) {
                        input_alarm.setError("Please Enter Alarm Number");
                    }
                    else if (input_alarm.getText().toString().length() < 1) {
                        input_alarm.setError("Please Fill Minimum One Character");
                    }
                    else if (input_alarm.getText().toString().length() > 4) {
                        input_alarm.setError("Please Fill Between Four Character");
                    } else {
                        input_alarm.setError(null);
                    }
                    if (input_confirm_alarm.getText().toString().length() == 0) {
                        input_confirm_alarm.setError("Please Enter Confirm Alarm Number");
                    }
                    else if(!input_alarm.getText().toString().trim().equalsIgnoreCase(input_confirm_alarm.getText().toString().trim()))
                    {
                        Toast.makeText(RetrofitPutExample.this,"Alarm Number and Confirm Alarm Number Not Matched", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        input_confirm_alarm.setError(null);

                        try {
                            SetFalseAlarmCall();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
            }
            else {
            Utilities.showNoConnectionToast(this);
        }
    }



    public void SetFalseAlarmCall() {
        AlarmModel alarmModel = new AlarmModel(sharedPreferences.getString("userid",""),
                input_alarm.getText().toString().trim(),
                new UpdatedBy(sharedPreferences.getString("userid","")));


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<AlarmOutput> call = api.AlarmInfo(
                "application/json;charset=UTF-8",
                sharedPreferences.getString("tokenid",""),
                sharedPreferences.getString("userid",""),
                sharedPreferences.getString("roleid",""),
                Constants.SET_FALSE_ALARM,
                alarmModel);

        call.enqueue(new Callback<AlarmOutput>() {
            @Override
            public void onResponse(Call<AlarmOutput> call, Response<AlarmOutput> response) {

               // A a = response.body()
                AlarmOutput alarmOutput=response.body();

                if (response.code() == 200 ) {

                        es.putString("userId",alarmOutput.getUserId());
                        es.putString("falseAlarm",alarmOutput.getFalseAlarm());
                        es.putString("userId", alarmOutput.getUserId());

                        es.commit();


                    Toast.makeText(RetrofitPutExample.this, "Succcess!!!", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(RetrofitPutExample.this,MainActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(RetrofitPutExample.this, "Fail!!!", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<AlarmOutput> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
