package com.example.exuberandroid.sentinel_module.Models;

public class RetrofitAlarmModel {
    String userId,falseAlarm,updatedBy;

    public RetrofitAlarmModel(String userId, String falseAlarm, String updatedBy) {
        this.userId = userId;
        this.falseAlarm = falseAlarm;
        this.updatedBy = updatedBy;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFalseAlarm() {
        return falseAlarm;
    }

    public void setFalseAlarm(String falseAlarm) {
        this.falseAlarm = falseAlarm;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
