package com.example.exuberandroid.sentinel_module.Activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.CustomViews.CircularImageView;
import com.example.exuberandroid.sentinel_module.Models.imageupload.UploadImageOutput;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Api;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    private Toolbar mToolbar;
    private TextView toolbarTV;
    private CircularImageView profilePicIV;
    TextView text_personal_info,txtAddress,txtEmail,txtCN,txtBGroup,txtallergies,txtdiabetes,txtName
            ,txtDoctorDetails,txtprimaryHospital,txtHealthInsCompy,txtHealthIncId,updateBT;
    EditText addressET,emailET, bloodGroupET,contactNoTV,allergiesET,diabetesET,nameET
            ,DoctorDetailsET,primaryHospitalET,HealthInsCompyET,HealthIncIdET;
    private Bitmap imageForUpload;
    private String captured_image;
    private File file;





    private static OkHttpClient.Builder builder;


    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();

        init();
    }

    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("My Profile");

        text_personal_info=(TextView)findViewById(R.id.text_personal_info);
        txtAddress=(TextView)findViewById(R.id.txtAddress);
        txtEmail=(TextView)findViewById(R.id.txtEmail);
        txtCN=(TextView)findViewById(R.id.txtCN);
        txtBGroup=(TextView)findViewById(R.id.txtBGroup);
        txtallergies=(TextView)findViewById(R.id.txtallergies);
        //txtdiabetes=(TextView)findViewById(R.id.txtdiabetes);
        txtName=(TextView)findViewById(R.id.txtName);
        txtDoctorDetails=(TextView)findViewById(R.id.txtDoctorDetails);
        txtprimaryHospital=(TextView)findViewById(R.id.txtprimaryHospital);
        txtHealthInsCompy=(TextView)findViewById(R.id.txtHealthInsCompy);
        txtHealthIncId=(TextView)findViewById(R.id.txtHealthIncId);
        updateBT=(TextView)findViewById(R.id.updateBT);
        updateBT.setOnClickListener(this);
        profilePicIV = (CircularImageView) findViewById(R.id.profilePicIV);
        profilePicIV.setOnClickListener(this);



        emailET = (EditText)findViewById(R.id.emailET);
        addressET = (EditText)findViewById(R.id.addressET);
        bloodGroupET = (EditText)findViewById(R.id.bloodGroupET);
        allergiesET=(EditText)findViewById(R.id.allergiesET);
        //diabetesET=(EditText)findViewById(R.id.diabetesET);
        nameET=(EditText)findViewById(R.id.nameET);
        contactNoTV = (EditText)findViewById(R.id.contactNoTV);
        DoctorDetailsET=(EditText)findViewById(R.id.DoctorDetailsET);
        primaryHospitalET=(EditText)findViewById(R.id.primaryHospitalET);
        HealthInsCompyET=(EditText)findViewById(R.id.HealthInsCompyET);
        HealthIncIdET=(EditText)findViewById(R.id.HealthIncIdET);


        emailET.setText(sharedPreferences.getString("email",""));
        nameET.setText(sharedPreferences.getString("name", ""));
        contactNoTV.setText(sharedPreferences.getString("phno",""));
        addressET.setText(sharedPreferences.getString("address",""));
        allergiesET.setText(sharedPreferences.getString("allergi",""));
        //diabetesET.setText(sharedPreferences.getString("diabetes",""));
        bloodGroupET.setText(sharedPreferences.getString("bloodgrp",""));
        DoctorDetailsET.setText(sharedPreferences.getString("doctorname",""));
        primaryHospitalET.setText(sharedPreferences.getString("primaryhospital",""));
        HealthInsCompyET.setText(sharedPreferences.getString("healthinsurancecpny",""));
        HealthIncIdET.setText(sharedPreferences.getString("healthinsuranceid",""));


        /////////////Profile Image.....................

        String url=sharedPreferences.getString("imgurl","");

        if (url == null)
        {

            profilePicIV.setImageResource(R.drawable.user_profile);

        }
        else
        {
            if (url.isEmpty())
            {
                profilePicIV.setImageResource(R.drawable.user_profile);

            }
            else
            {
                Picasso.with(this)
                        .load(url)
                        .placeholder(R.drawable.user_profile)
                        .error(R.drawable.user_profile)
                        .into(profilePicIV);

            }
        }








    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean validateTextFields()
    {
        if (nameET.getText().toString().length() == 0) {
            nameET.setError("Please Enter Name");
            return false;
        }
        else {
            nameET.setError(null);
        }
        if (contactNoTV.getText().toString().length() == 0) {
            contactNoTV.setError("Please Enter Phone Number");
            return false;
        }
        else {
            contactNoTV.setError(null);
        }
        /*if (addressET.getText().toString().length() == 0) {
            addressET.setError("Please Enter Address");
            return false;
        }
        else {
            addressET.setError(null);
        }
        if (allergiesET.getText().toString().length() == 0) {
            allergiesET.setError("Please Enter If You Have Any Allergi");
            return false;
        }
        else {
            allergiesET.setError(null);
        }
        *//*if (diabetesET.getText().toString().length() == 0) {
            diabetesET.setError("Please Enter If You Have Diabetes");
            return false;
        }
        else {
            diabetesET.setError(null);
        }*//*
        if (bloodGroupET.getText().toString().length() == 0) {
            bloodGroupET.setError("Please Enter If You Have Diabetes");
            return false;
        }
        else {
            bloodGroupET.setError(null);
        }
        if (DoctorDetailsET.getText().toString().length() == 0) {
            DoctorDetailsET.setError("Please Fill Between Four Character");
            return false;
        }
        else {
            DoctorDetailsET.setError(null);
        }
        if (primaryHospitalET.getText().toString().length() == 0) {
            primaryHospitalET.setError("Please Fill Between Four Character");
            return false;
        }
        else {
            primaryHospitalET.setError(null);
        }
        if (HealthInsCompyET.getText().toString().length() == 0) {
            HealthInsCompyET.setError("Please Fill Between Four Character");
            return false;
        }
        else {
            HealthInsCompyET.setError(null);
        }
        if (HealthIncIdET.getText().toString().length() == 0) {
            HealthIncIdET.setError("Please Fill Between Four Character");
            return false;
        }
        else {
            HealthIncIdET.setError(null);
        }*/
        return true;
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.profilePicIV:
                final Dialog dialog = new Dialog(ProfileActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.chooser_dialouge);
                LinearLayout CameraBtn = (LinearLayout) dialog.findViewById(R.id.ll_camera_parent);
                LinearLayout GalleryBtn = (LinearLayout) dialog.findViewById(R.id.ll_gallery_parent);
                CameraBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
                        captured_image = System.currentTimeMillis() + ".jpg";
                        file = new File(Environment.getExternalStorageDirectory(), captured_image);
                        captured_image = file.getAbsolutePath();
                        Uri outputFileUri = Uri.fromFile(file);
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
                        startActivityForResult(cameraIntent, 1);

                    }
                });
                GalleryBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();

                        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        intent.setType("image/*");
                        startActivityForResult(Intent.createChooser(intent, "Select File"), 2);
                    }
                });
                dialog.show();
                break;
            case R.id.updateBT:
                if (validateTextFields()) {
                    if (Utilities.isOnline(this)) {

                        MyProfileApiCall();

                    }
                    else {
                        Utilities.showNoConnectionToast(this);
                    }
                }
                break;
            }
    }




    private void uploadImage(Bitmap bitmap) {

        //start
        pd=new ProgressDialog(ProfileActivity.this);
        pd.setMessage("Please Wait...");
        pd.setCancelable(true);
        pd.setIndeterminate(false);
        pd.setCancelable(false);
        pd.show();

        File fileimage = Utilities.bitmapToFile(this, bitmap, true);

        RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), fileimage);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", fileimage.getName(), reqFile);

        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"),  String.valueOf(sharedPreferences.getString("userid", "")));


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Constants.DOMAIN).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        Api api = retrofit.create(Api.class);

        Call<UploadImageOutput> call = (Call<UploadImageOutput>) api.uploadImage(body,
                userIdBody);
        call.enqueue(new Callback<UploadImageOutput>() {
            @Override
            public void onResponse(Call<UploadImageOutput> call, Response<UploadImageOutput> response) {


                // close
                pd.dismiss();
                UploadImageOutput uploadImageOutput = response.body();

                //Checking for response code
                if (response.code() == 200 ) {


                    String uploadImageUrl = uploadImageOutput.getProfilePic();

                    Log.e("Uploaded url",uploadImageUrl);

                    es.putString("imgurl",uploadImageUrl);
                    es.commit();

                    if (uploadImageUrl == null)
                    {

                        profilePicIV.setImageResource(R.drawable.user_profile);

                    }
                    else
                    {
                        if (uploadImageUrl.isEmpty())
                        {
                            profilePicIV.setImageResource(R.drawable.user_profile);

                        }
                        else
                        {
                            Picasso.with(ProfileActivity.this)
                                    .load(uploadImageUrl)
                                    .placeholder(R.drawable.user_profile)
                                    .error(R.drawable.user_profile)
                                    .into(profilePicIV);

                        }
                    }
                }
                else
                {

                }

            }

            @Override
            public void onFailure(Call<UploadImageOutput> call, Throwable t) {
                //close
                pd.dismiss();

            }
        });











    }

    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }



    public void ProfileImageApiCall() {
        JSONObject jsonObject = null;
        try {

            jsonObject = new JSONObject();

            jsonObject.put("userId",sharedPreferences.getString("userid", ""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");

            jsonObject.put("profilePic",file);



        } catch (JSONException e) {
            e.printStackTrace();
        }


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jsonObject.toString());
            Log.d("Profile_Pic_Object", String.valueOf(jsonObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.post(null, Constants.APP_SUBMIT_PROFILE_IMAGE_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("ImageResponse", Response);

                Log.v("Image_Status_code", statusCode+"");


                if (statusCode==200) {
                    try {

                        JSONObject object = new JSONObject(Response);

                        es.putString(Constants.USER_ID, object.getString("userId"));

                        es.putString(String.valueOf(file),object.getString("profilePic"));
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {

                }


            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Image_Error",error.toString());
                Log.e("Image_Errorstatus", String.valueOf(statusCode));

            }

        });


    }



    public void MyProfileApiCall() {

        JSONObject jObject = new JSONObject();
        try {

            jObject.put("userId",sharedPreferences.getString("userid", ""));
            //Constants.USER_ID=sharedPreferences.getString("userid", "");

            jObject.put("userName",nameET.getText().toString().trim());
            //Constants.USER_NAME = nameET.getText().toString();

            jObject.put("phoneNumber",contactNoTV.getText().toString().trim());
            //Constants.USER_PHNO = contactNoTV.getText().toString();

            jObject.put("address",addressET.getText().toString().trim());
            //Constants.USER_ADDRESS = addressET.getText().toString();

            jObject.put("userEmail",emailET.getText().toString().trim());
            //Constants.USER_EMAIL=emailET.getText().toString();

            jObject.put("bloodGroup",bloodGroupET.getText().toString().trim());
            //Constants.USER_BLOOD_GRP=bloodGroupET.getText().toString();

            jObject.put("doctorName",DoctorDetailsET.getText().toString().trim());
            //Constants.USER_DOCTOR_NAME=DoctorDetailsET.getText().toString();

            jObject.put("primaryHospital",primaryHospitalET.getText().toString().trim());
            //Constants.USER_PRIMARY_HOSPITAL=primaryHospitalET.getText().toString();

            jObject.put("healthInsuranceCompany",HealthInsCompyET.getText().toString().trim());
            //Constants.USER_HEALTH_INSURANCE_COMPANY=HealthInsCompyET.getText().toString();

            jObject.put("healthInsuranceId",HealthIncIdET.getText().toString().trim());
            //Constants.USER_HEALTH_INSURANCEID=HealthIncIdET.getText().toString();

            jObject.put("allergies",allergiesET.getText().toString().trim());
            //Constants.USER_ALLERGIES=allergiesET.getText().toString();

            jObject.put("diabetes","");
            //Constants.USER_DIABETES=diabetesET.getText().toString();


            JSONObject updatedby = new JSONObject();
            updatedby.put("userId", sharedPreferences.getString("userid", ""));
            //Constants.USER_ID=sharedPreferences.getString("userid", "");
            jObject.put("updatedBy",updatedby);
            Log.e("UpdatedBy",sharedPreferences.getString("userid", ""));





        } catch (Exception e) {
            e.printStackTrace();
        }

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("Object", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));
        Log.e("Token",sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SHOW_USER_PROFILE);
        Log.e("servicename",Constants.SHOW_USER_PROFILE);

        asyncHttpClient.put(null, Constants.APP_USER_PROFILE_UPDATE_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("Profile_Response", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==200) {

                    try {
                        JSONObject job = new JSONObject(Response);
                        JSONObject updateby = job.getJSONObject("updatedBy");

                        es.putString("userid",job.getString("userId"));

                        es.putString("name",job.getString("userName"));

                        es.putString("phno",job.getString("phoneNumber"));

                        es.putString("address",job.getString("address"));

                        es.putString("email",job.getString("userEmail"));

                        es.putString("bloodgrp",job.getString("bloodGroup"));

                        es.putString("doctorname",job.getString("doctorName"));

                        es.putString("primaryhospital",job.getString("primaryHospital"));

                        es.putString("healthinsurancecpny",job.getString("healthInsuranceCompany"));

                        es.putString("healthinsuranceid",job.getString("healthInsuranceId"));

                        es.putString("allergi",job.getString("allergies"));

                        es.putString("diabetes",job.getString("diabetes"));

                        es.putString(Constants.USER_ID,updateby.getString("userId"));





                        es.commit();

                        Log.d("UserId", Constants.USER_ID);
                        Log.d("CONTACT_NO", Constants.USER_PHNO);
                        Log.d("updatedBYE", Constants.USER_ID);
                        Log.d("BLOOD_GRP",Constants.USER_BLOOD_GRP);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                    Toast.makeText(ProfileActivity.this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(ProfileActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(ProfileActivity.this, "Profile not updated", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

            }
        });

    }






    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1 && resultCode == this.RESULT_OK) {
            String imagePath = compressImage(captured_image);
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            imageForUpload = bitmap;
            //ProfileImageApiCall();
            uploadImage(bitmap);
            //profilePicIV.setImageBitmap(imageForUpload);
        }
        if (requestCode == 2 && resultCode == this.RESULT_OK) {
            Uri selectedImageUri = data.getData();
            String pathforcalculatesize = getRealPathFromURI(selectedImageUri);
            File file = new File(pathforcalculatesize);
            final String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + Constants.CHAT_IMAGES_DIRECTORY;
            File fDir = new File(dir);
            if (!fDir.exists()) {
                fDir.mkdirs();
            }
            File f = new File(fDir, String.valueOf(System.currentTimeMillis()) + ".png");
            boolean fileCopied = copy(file, f);
            String imaptah = compressImage(f.getAbsolutePath());
            Bitmap bitmap = BitmapFactory.decodeFile(imaptah);
            imageForUpload = bitmap;
            //ProfileImageApiCall();
            uploadImage(bitmap);
            //profilePicIV.setImageBitmap(imageForUpload);
            f.delete();
        }
    }

    ///



    ///



    public String compressImage(String filePath) {

//        String filePath = getRealPathFromURI(imageUri);
        Bitmap scaledBitmap = null;

        BitmapFactory.Options options = new BitmapFactory.Options();

//      by setting this field as true, the actual bitmap pixels are not loaded in the memory. Just the bounds are loaded. If
//      you try the use the bitmap here, you will get null.
        options.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(filePath, options);

        int actualHeight = options.outHeight;
        int actualWidth = options.outWidth;

//      max Height and width values of the compressed image is taken as 816x612

        float maxHeight = 816.0f;
        float maxWidth = 612.0f;
        float imgRatio = actualWidth / actualHeight;
        float maxRatio = maxWidth / maxHeight;

//      width and height values are set maintaining the aspect ratio of the image

        if (actualHeight > maxHeight || actualWidth > maxWidth) {
            if (imgRatio < maxRatio) {
                imgRatio = maxHeight / actualHeight;
                actualWidth = (int) (imgRatio * actualWidth);
                actualHeight = (int) maxHeight;
            } else if (imgRatio > maxRatio) {
                imgRatio = maxWidth / actualWidth;
                actualHeight = (int) (imgRatio * actualHeight);
                actualWidth = (int) maxWidth;
            } else {
                actualHeight = (int) maxHeight;
                actualWidth = (int) maxWidth;

            }
        }

//      setting inSampleSize value allows to load a scaled down version of the original image

        options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);

//      inJustDecodeBounds set to false to load the actual bitmap
        options.inJustDecodeBounds = false;

//      this options allow android to claim the bitmap memory if it runs low on memory
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16 * 1024];

        try {
//          load the bitmap from its path
            bmp = BitmapFactory.decodeFile(filePath, options);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();

        }
        try {
            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();
        }

        float ratioX = actualWidth / (float) options.outWidth;
        float ratioY = actualHeight / (float) options.outHeight;
        float middleX = actualWidth / 2.0f;
        float middleY = actualHeight / 2.0f;

        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));

//      check the rotation of the image and display it properly
        ExifInterface exif;
        try {
            exif = new ExifInterface(filePath);

            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 0);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                Log.d("EXIF", "Exif: " + orientation);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                    scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
                    true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(filePath);

//          write the compressed bitmap at the destination specified by filename.
            scaledBitmap.compress(Bitmap.CompressFormat.PNG, 80, out);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return filePath;

    }


    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = this.getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    public boolean copy(File source, File target) {
        try {
            InputStream in = new FileInputStream(source);
            OutputStream out = new FileOutputStream(target);
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            in.close();
            out.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }


    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }

        return inSampleSize;
    }
}
