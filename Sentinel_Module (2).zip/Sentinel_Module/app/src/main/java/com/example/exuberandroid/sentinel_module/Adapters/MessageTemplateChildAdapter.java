package com.example.exuberandroid.sentinel_module.Adapters;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Models.MessageTemplateMainModel;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateModel;
import com.example.exuberandroid.sentinel_module.R;

import java.util.ArrayList;
import java.util.List;

public class MessageTemplateChildAdapter extends RecyclerView.Adapter<MessageTemplateChildAdapter.MyViewHolder> {

    List<MessageTemplateModel> adapterList = new ArrayList<>();
    private Context mContext;

    private int lastSelectedPosition = 1;



    public MessageTemplateChildAdapter(Context context, ArrayList<MessageTemplateModel> adapterList) {

        this.mContext=context;
        this.adapterList=adapterList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_child_message_temp,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {



        holder.textMsg.setText(adapterList.get(position).getMessage());


        if (adapterList.get(position).isSelected())
        {
            holder.image.setVisibility(View.VISIBLE);

            Log.e("Selected", "TRUE");
            Log.e("Selected", adapterList.get(position).getMessage());

        }
        else
        {
            holder.image.setVisibility(View.GONE);
        }


    }

    @Override
    public int getItemCount() {

        return adapterList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView textMsg;
        ImageView image;


        public MyViewHolder(final View itemView) {
            super(itemView);

            textMsg=(TextView)itemView.findViewById(R.id.textMsg);

            image=(ImageView)itemView.findViewById(R.id.image);

            itemView.setOnClickListener(this);

            }

        @Override
        public void onClick(View view) {

            int position = getLayoutPosition();

            for(int index =0 ; index<adapterList.size();index++)
            {
                if(index == position)
                {
                    adapterList.get(index).setSelected(true);
                }
                else
                {
                    adapterList.get(index).setSelected(false);
                }
            }

            notifyDataSetChanged();

        }
    }



}
