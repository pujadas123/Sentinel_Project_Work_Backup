package com.example.exuberandroid.sentinel_module.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class SetFalseAlarmNoActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    EditText input_alarm,input_confirm_alarm;
    TextView doneBTN;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;



    private TextView textmsg2,buttonOk;
    AlertDialog alertDialog;
    AlertDialog.Builder alert;
    ProgressDialog pd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_false_alarm_no);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();

        init();
    }



    public void init(){

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("False Alarm");

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);

        input_alarm=(EditText)findViewById(R.id.input_alarm);
        input_alarm.addTextChangedListener(this);

        input_confirm_alarm=(EditText)findViewById(R.id.input_confirm_alarm);
        input_confirm_alarm.addTextChangedListener(this);

        doneBTN=(TextView)findViewById(R.id.doneBTN);
        doneBTN.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (Utilities.isOnline(this)) {

            if (input_alarm.getText().toString().length() == 0) {
                input_alarm.setError("Please Enter Alarm Number");
            }
            else if (input_alarm.getText().toString().length() < 1) {
                input_alarm.setError("Please Fill Minimum One Character");
            }
            else if (input_alarm.getText().toString().length() > 4) {
                input_alarm.setError("Please Fill Between Four Character");
            } else {
                input_alarm.setError(null);
            }
            if (input_confirm_alarm.getText().toString().length() == 0) {
                input_confirm_alarm.setError("Please Enter Confirm Alarm Number");
            }
            else if(!input_alarm.getText().toString().trim().equalsIgnoreCase(input_confirm_alarm.getText().toString().trim()))
            {
                Toast.makeText(SetFalseAlarmNoActivity.this,"Alarm Number and Confirm Alarm Number Not Matched", Toast.LENGTH_SHORT).show();
            }
            else {
                input_confirm_alarm.setError(null);

                try {
                    AlarmDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        } else {
            Utilities.showNoConnectionToast(this);
        }

    }




    public void SetFalseAlarmCall() {

        JSONObject jObject = new JSONObject();
        try {

            jObject.put("userId",sharedPreferences.getString("userid", ""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");
            Log.e("uid",sharedPreferences.getString("userid", ""));

            jObject.put("falseAlarm",input_alarm.getText().toString().trim());
            Constants.FALSE_ALARM = input_alarm.getText().toString();

            JSONObject updatedby = new JSONObject();
            updatedby.put("userId", sharedPreferences.getString("userid", ""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");
            jObject.put("updatedBy",updatedby);
            Log.e("UpdatedBy",sharedPreferences.getString("userid", ""));

        } catch (Exception e) {
            e.printStackTrace();
        }

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("Object", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SET_FALSE_ALARM);
        Log.e("servicename",Constants.SET_FALSE_ALARM);

        asyncHttpClient.put(null, Constants.APP_SET_FALSE_AlARM_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(SetFalseAlarmNoActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("OTP_Response", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==200) {

                    try {
                        JSONObject job = new JSONObject(Response);
                        JSONObject updateby = job.getJSONObject("updatedBy");

                        es.putString(Constants.USER_ID,job.getString("userId"));
                        //es.putString("alarmcode", job.getString("falseAlarm"));
                        es.putString("alarm", job.getString("falseAlarm"));
                        es.putString(Constants.USER_ID,updateby.getString("userId"));

                        es.commit();
                        Constants.FALSE_ALARM=job.getString("falseAlarm");

                        Log.d("UserId", Constants.USER_ID);
                        Log.d("false_Alarm", Constants.FALSE_ALARM);
                        Log.d("updatedBYE", Constants.USER_ID);

                        pd.dismiss();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Intent intent=new Intent(SetFalseAlarmNoActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(SetFalseAlarmNoActivity.this, "Alarm Not Set Successfull", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

            }
        });

    }



    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }


    private void AlarmDialog() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View locationDialog = li.inflate(R.layout.dialog_alarm, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        textmsg2 = (TextView) locationDialog.findViewById(R.id.textmsg2);
        buttonOk=(TextView)locationDialog.findViewById(R.id.buttonOk);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(locationDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(true);


        //Displaying the alert dialog
        alertDialog.show();

        textmsg2.setText(input_confirm_alarm.getText().toString().trim());


        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SetFalseAlarmCall();
            }
        });
    }
}
