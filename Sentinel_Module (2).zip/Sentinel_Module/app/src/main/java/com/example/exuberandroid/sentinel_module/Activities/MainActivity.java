package com.example.exuberandroid.sentinel_module.Activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.fragments.NavigationFragment;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence;
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig;

public class MainActivity extends AppCompatActivity {
    protected DrawerLayout drawerLayout;
    private NavigationFragment mNavigationFragment;
    private Toolbar mToolbar;
    private TextView toolbarTV;
    private ImageView messageImageView, notificationCountIV;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private ImageView shield_img, msg_img, location_img, community_img, medical_img;

    private static final String SHOWCASE_ID = "1";

    private boolean isSpeakButtonLongPressed = false;


    Vibrator mVibrator;

    private EditText editTextAlarm;
    private TextView buttonSubmit,txtTimer,buttonOk,disableSubmit,txtShowAlarmNo,buttonYes,buttonCancel;
    AlertDialog alertDialog, Faq_alertDialog,DisablealertDialog;
    AlertDialog.Builder alert, alertFAQ,disablealert;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;


    private CountDownTimer countDownTimer;
    private boolean timerHasStarted = false;
    private final long startTime = 10 * 1000;
    private final long interval = 1 * 1000;
    private NotificationCompat.Builder notificationBuilder;
    private NotificationManager notificationManager;

    private GoogleMap mMap;
    LocationManager locationManager;
    GPSTracker gps;
    String country_name = null;
    double latitude,longitude;


    String medical_msg="3";
    String message_msg="4";
    String community_msg="5";




    String medical="Medical emergency message.";
    String community="Community watch message.";
    String message="I am in emergency Protect me right now.";

    //String location="http://maps.google.com/?q=";

    String locationId="2";
    String MapUrl;

    private final int delay = 15000;
    private final Handler handler=new Handler();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();

        init();

        presentShowcaseSequence();

        //scheduleSendLocation();


    }


    private void init() {


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        setSupportActionBar(mToolbar);
        toolbarTV.setText("Sentinel");

        mVibrator = (Vibrator)getSystemService(MainActivity.VIBRATOR_SERVICE);

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);

        //ImageView....

        shield_img = (ImageView) findViewById(R.id.shield_img);
        shield_img.setOnLongClickListener(speakHoldListener);
        shield_img.setOnTouchListener(speakTouchListener);


        msg_img = (ImageView) findViewById(R.id.msg_img);
        msg_img.setOnLongClickListener(speakHoldListener);
        msg_img.setOnTouchListener(speakTouchListener);

        location_img = (ImageView) findViewById(R.id.location_img);
        location_img.setOnLongClickListener(speakHoldListener);
        location_img.setOnTouchListener(speakTouchListener);

        community_img = (ImageView) findViewById(R.id.community_img);
        community_img.setOnLongClickListener(speakHoldListener);
        community_img.setOnTouchListener(speakTouchListener);

        medical_img = (ImageView) findViewById(R.id.medical_img);
        medical_img.setOnLongClickListener(speakHoldListener);
        medical_img.setOnTouchListener(speakTouchListener);
        //


        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mNavigationFragment = (NavigationFragment) getSupportFragmentManager().findFragmentById(R.id.navFragment);
        mNavigationFragment.setUp(R.id.navFragment, drawerLayout, mToolbar);


        /// Start Get Lat Long....

        if (ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions((Activity) this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                ActivityCompat.requestPermissions((Activity) this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        } else {
            gps = new GPSTracker(MainActivity.this);

            // check if GPS enabled
            if (gps.canGetLocation()) {

                latitude = gps.getLatitude();
                longitude = gps.getLongitude();

                Log.e("LATITUDE", String.valueOf(latitude));
                Log.e("LONGITUDE", String.valueOf(longitude));
            } else {
                gps.showSettingsAlert();
            }

            ////////////////
            LocationManager lm = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
            Geocoder geocoder = new Geocoder(getApplicationContext());
            for (String provider : lm.getAllProviders()) {
                @SuppressWarnings("ResourceType") Location location = lm.getLastKnownLocation(provider);
                if (location != null) {
                    try {
                        List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                        if (addresses != null && addresses.size() > 0) {
                            country_name = addresses.get(0).getCountryName();
                            break;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        MapUrl=latitude + "," + longitude;


        ///End Get Lat Long....

    }

    public void scheduleSendLocation() {
        handler.postDelayed(new Runnable() {
            public void run() {
                LocationApiCall();
                handler.postDelayed(this, delay);
            }
        }, delay);
    }





    /////
    private View.OnLongClickListener speakHoldListener = new View.OnLongClickListener() {

        @Override
        public boolean onLongClick(View pView) {
            // Do something when your hold starts here.
            isSpeakButtonLongPressed = true;
            //Toast.makeText(MainActivity.this, "Long Pressed", Toast.LENGTH_SHORT).show();

            switch (pView.getId()){
                /*case R.id.shield_img:
                    try {
                        falseAlarm();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;*/
                case R.id.msg_img:
                    try {
                        EmergencyMsg();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.location_img:
                    try {
                        ShareLocation();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.community_img:
                    try {
                        CommunityWatch();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.medical_img:
                    try {
                        MedicalHelp();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }
            return true;
        }
    };


    private View.OnTouchListener speakTouchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View pView, MotionEvent pEvent) {
            switch (pView.getId()){
                case R.id.shield_img:
                    pView.onTouchEvent(pEvent);
                    // We're only interested in when the button is released.
                    if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                        // We're only interested in anything if our speak button is currently pressed.
                        if (isSpeakButtonLongPressed) {
                            // Do something when the button is released.
                            isSpeakButtonLongPressed = false;
                            try {
                                mVibrator.vibrate(1000);
                                falseAlarm();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                    break;

                case R.id.msg_img:
                    pView.onTouchEvent(pEvent);
                    // We're only interested in when the button is released.
                    if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                        // We're only interested in anything if our speak button is currently pressed.
                        if (isSpeakButtonLongPressed) {
                            // Do something when the button is released.
                            isSpeakButtonLongPressed = false;
                        }
                    }
                    break;
                case R.id.location_img:
                    pView.onTouchEvent(pEvent);
                    // We're only interested in when the button is released.
                    if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                        // We're only interested in anything if our speak button is currently pressed.
                        if (isSpeakButtonLongPressed) {
                            // Do something when the button is released.
                            isSpeakButtonLongPressed = false;
                        }
                    }
                    break;
                case R.id.community_img:
                    pView.onTouchEvent(pEvent);
                    // We're only interested in when the button is released.
                    if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                        // We're only interested in anything if our speak button is currently pressed.
                        if (isSpeakButtonLongPressed) {
                            // Do something when the button is released.
                            isSpeakButtonLongPressed = false;
                        }
                    }
                    break;
                case R.id.medical_img:
                    pView.onTouchEvent(pEvent);
                    // We're only interested in when the button is released.
                    if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                        // We're only interested in anything if our speak button is currently pressed.
                        if (isSpeakButtonLongPressed) {
                            // Do something when the button is released.
                            isSpeakButtonLongPressed = false;
                        }
                    }
                    break;
            }


            /*pView.onTouchEvent(pEvent);
            // We're only interested in when the button is released.
            if (pEvent.getAction() == MotionEvent.ACTION_UP) {
                // We're only interested in anything if our speak button is currently pressed.
                if (isSpeakButtonLongPressed) {
                    // Do something when the button is released.
                    isSpeakButtonLongPressed = false;
                }
            }*/
            return false;
        }
    };

    /////


    //Dialog start.....
    private boolean validate_falseAlarm(){
        if (editTextAlarm.getText().toString().length() == 0) {
            editTextAlarm.setError("Please Enter False Alarm Number");
            return false;
        }
        if (editTextAlarm.getText().toString().trim().length() < 1){
            editTextAlarm.setError("Please Enter Minimum 1 False Alarm Number");
            return false;
        }
        if (editTextAlarm.getText().toString().trim().length() > 4){
            editTextAlarm.setError("Please Enter Maximum 4 False Alarm Number");
            return false;
        }
        if (!editTextAlarm.getText().toString().trim().equals(txtShowAlarmNo.getText().toString().trim())){
            editTextAlarm.setError("Please Enter Proper Alarm Number");
            return false;
        }
        else {
            editTextAlarm.setError(null);

            try {
                DisableAlarm();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return true;
    }



    private void falseAlarm() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View confirmDialog = li.inflate(R.layout.dialog_false_alarm, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        buttonSubmit = (TextView) confirmDialog.findViewById(R.id.buttonSubmit);
        txtTimer=(TextView)confirmDialog.findViewById(R.id.txtTimer);
        editTextAlarm = (EditText) confirmDialog.findViewById(R.id.editTextAlarm);
        txtShowAlarmNo=(TextView)confirmDialog.findViewById(R.id.txtShowAlarmNo);
        txtShowAlarmNo.setText(sharedPreferences.getString("alarm",""));

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(confirmDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();

        ////////////

        countDownTimer = new MyCountDownTimer(startTime, interval);
        //txtTimer.setText(txtTimer.getText() + String.valueOf(startTime / 1000));


        if (!timerHasStarted) {
            countDownTimer.start();
            timerHasStarted = true;
        } else {
            countDownTimer.cancel();
            timerHasStarted = false;
        }




        /////////////

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //alertDialog.dismiss();

                //Getting the user entered otp from edittext
                final String otp = editTextAlarm.getText().toString().trim();
                validate_falseAlarm();
            }
        });
    }


    private void ShareLocation() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View locationDialog = li.inflate(R.layout.dialog_share_location, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        buttonYes = (TextView) locationDialog.findViewById(R.id.buttonYes);
        buttonCancel=(TextView)locationDialog.findViewById(R.id.buttonCancel);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(locationDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();


        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserShareLocationApi();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
    }


    /////Location...............

    public void UserShareLocationApi() {
        JSONObject jsonObject = null;
        try {

            jsonObject = new JSONObject();

            /*JSONObject jsonObject1 = new JSONObject();
            JSONObject jsonObject2=new JSONObject();

            jsonObject2.put("emergencyTypeId",locationId);
            jsonObject1.put("emergencyTypeId",jsonObject2);
            jsonObject.put("messageId",jsonObject1);*/

            jsonObject.put("message", MapUrl);



        } catch (JSONException e) {
            e.printStackTrace();
        }


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jsonObject.toString());
            Log.d("LocationObject", String.valueOf(jsonObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_REGISTER_LOCATION_MESSAGE_BY_USERID);
        Log.e("servicename",Constants.USER_REGISTER_LOCATION_MESSAGE_BY_USERID);


        asyncHttpClient.post(null, Constants.APP_REGISTER_LOCATION_MESSAGE_BY_USERID_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("LocationResponse", Response);

                Log.v("Location_Status_code", statusCode+"");

                if (statusCode==201) {

                    Toast.makeText(MainActivity.this, "Location Shared Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                    scheduleSendLocation();

                }
                else {

                    Toast.makeText(MainActivity.this, "Location Share Not Successfull", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Location_Error",error.toString());
                Log.e("Location_Errorstatus", String.valueOf(statusCode));

            }

        });


    }






    //////Location............


    ///Dislog end...

    private void presentShowcaseSequence() {

        ShowcaseConfig config=new ShowcaseConfig();
        config.setDelay(500);
        //config.setMaskColor(R.color.today);

        MaterialShowcaseSequence sequence=new MaterialShowcaseSequence(this, SHOWCASE_ID);
        sequence.setConfig(config);

        sequence.addSequenceItem(shield_img, "The Safeguard Shield is the primary means of safety. In emergency situations, most times, you cannot do anything– this feature uses your preparedness beforehand and leverages that during crisis.", "GOT IT");
        sequence.addSequenceItem(msg_img, "Panic Button lets you alert your Sentinels with no delay. It is a more serious alert, which indicates grave danger.", "GOT IT");
        sequence.addSequenceItem(community_img, "Alert Sentinels around you requesting immediate aid. As more people use the app, your Sentinel safety net gets bigger.", "GOT IT");
        sequence.addSequenceItem(medical_img, "Contact Sentinels quickly during Medical emergencies and give them access to basic health information. Please complete profile with information.", "GOT IT");
        sequence.addSequenceItem(location_img, "Send a tracking link to your Sentinels. Let them watch over you for a certain time period.", "GOT IT");
        sequence.start();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.action_settings:
                //Toast.makeText(getApplicationContext(),"Item 1 Selected",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(MainActivity.this,SettingsActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_help:
                //Toast.makeText(getApplicationContext(),"Item 2 Selected",Toast.LENGTH_LONG).show();
                Intent intent1=new Intent(MainActivity.this,HelpActivity.class);
                startActivity(intent1);
                return true;
            case R.id.action_logout:
                sharedPreferences = this.getSharedPreferences("PREF", 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.commit();
                Intent intent2=new Intent(this,LoginActivity.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }




    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            finishAffinity();
        }
    }



    private void ConfirmAlarm() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View confirmDialog = li.inflate(R.layout.dialog_confirm_faq, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        buttonOk=(TextView)confirmDialog.findViewById(R.id.buttonOk);

        //Creating an alertdialog builder
        alertFAQ = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alertFAQ.setView(confirmDialog);

        //Creating an alert dialog
        Faq_alertDialog = alertFAQ.create();
        Faq_alertDialog.setCancelable(false);

        //Displaying the alert dialog
        Faq_alertDialog.show();

        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(MainActivity.this, "Message Template Shared Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, MainActivity.class));

            }
        });
    }



    private void DisableAlarm() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View confirmDialog = li.inflate(R.layout.dialog_disable_faq, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        disableSubmit=(TextView)confirmDialog.findViewById(R.id.disableSubmit);

        //Creating an alertdialog builder
        disablealert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        disablealert.setView(confirmDialog);

        //Creating an alert dialog
        DisablealertDialog = disablealert.create();
        DisablealertDialog.setCancelable(false);


        //Displaying the alert dialog
        DisablealertDialog.show();


        if (timerHasStarted) {
            countDownTimer.cancel();
            timerHasStarted = false;
        } else {
           /* countDownTimer.start();
            timerHasStarted = true;*/
        }

        if (editTextAlarm.getText().toString().trim().equals(txtShowAlarmNo.getText().toString().trim())) {
            txtTimer.setVisibility(View.GONE);

            //mVibrator.vibrate(1000);


            disableSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(MainActivity.this, MainActivity.class));

                }
            });
        }




    }



    public class MyCountDownTimer extends CountDownTimer {
        public MyCountDownTimer(long startTime, long interval) {
            super(startTime, interval);
        }

        @Override
        public void onFinish() {
            //txtTimer.setText("Time's up!");
            if (editTextAlarm.getText().toString().trim().equals("")) {
                /*notificationBuilder = new NotificationCompat.Builder(MainActivity.this);
                notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                long[] v = {500, 1000};
                notificationBuilder.setVibrate(v);
                notificationManager.notify(1, notificationBuilder.build());*/

                txtTimer.setText("Time's up!");

                //mVibrator.vibrate(1000);

                ShieldActivateMsg();

                /*try {
                    alertDialog.dismiss();
                    ConfirmAlarm();
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
            }
            if (!editTextAlarm.getText().toString().trim().equals("") && !editTextAlarm.getText().toString().trim().equals(txtShowAlarmNo.getText().toString().trim())) {
                /*notificationBuilder = new NotificationCompat.Builder(MainActivity.this);
                notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                long[] v = {500, 1000};
                notificationBuilder.setVibrate(v);
                notificationManager.notify(1, notificationBuilder.build());*/

                txtTimer.setText("Time's up!");

                //mVibrator.vibrate(1000);

                ShieldActivateMsg();


                /*try {
                    alertDialog.dismiss();
                    ConfirmAlarm();
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
            }


        }

        @Override
        public void onTick(long millisUntilFinished) {
            txtTimer.setText("Left " + millisUntilFinished / 1000 + " (s)");
        }
    }





    ///////Shield Click...
    public void ShieldActivateMsg() {

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Exception cart) {
            cart.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_REGISTER_GENERAL_MESSAGE_BY_USERID);
        Log.e("servicename",Constants.USER_REGISTER_GENERAL_MESSAGE_BY_USERID);


        asyncHttpClient.post(null, Constants.APP_REGISTER_GENERAL_MESSAGE_BY_USERID_API, null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("MessageResponse", Response);

                Log.v("Status_code", statusCode+"");

                if (statusCode==201){
                    try {
                        alertDialog.dismiss();
                        ConfirmAlarm();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    /*Intent intent=new Intent(MainActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();*/
                }
                else {

                    //Toast.makeText(MainActivity.this, "Message Template Not Updated", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Update_Error",error.toString());
                Log.e("Update_Errorstatus", String.valueOf(statusCode));

            }

        });


    }




    /////Emergency_Message................

    private void EmergencyMsg() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View locationDialog = li.inflate(R.layout.dialog_share_location, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        TextView textmsg=(TextView)locationDialog.findViewById(R.id.textmsg);
        textmsg.setText("Do You Want To Share Emergency Message To Your Sentinels ?");
        buttonYes = (TextView) locationDialog.findViewById(R.id.buttonYes);
        buttonCancel=(TextView)locationDialog.findViewById(R.id.buttonCancel);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(locationDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();


        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserShareEmergencyMsgApi();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
    }

    public void UserShareEmergencyMsgApi() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Exception cart) {
            cart.printStackTrace();
        }

        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_REGISTER_PROTECTME_MESSAGE_BY_USERID);
        Log.e("servicename",Constants.USER_REGISTER_PROTECTME_MESSAGE_BY_USERID);


        asyncHttpClient.post(null, Constants.APP_REGISTER_PROTECTME_MESSAGE_BY_USERID_API, null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("MessageResponse", Response);

                Log.v("Message_Status_code", statusCode+"");

                if (statusCode==201) {

                    Toast.makeText(MainActivity.this, "Protect Me Emergency Message Shared Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else {

                    Toast.makeText(MainActivity.this, "Protect Me Emergency Message Share Not Successfull", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Message_Error",error.toString());
                Log.e("Message_Errorstatus", String.valueOf(statusCode));

            }

        });

    }


////////////////////Medical_Help.................

    private void MedicalHelp() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View locationDialog = li.inflate(R.layout.dialog_share_location, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        TextView textmsg=(TextView)locationDialog.findViewById(R.id.textmsg);
        textmsg.setText("Do You Want To Share Emergency Medical Help Message To Your Sentinels ?");
        buttonYes = (TextView) locationDialog.findViewById(R.id.buttonYes);
        buttonCancel=(TextView)locationDialog.findViewById(R.id.buttonCancel);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(locationDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();


        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserShareMedicalHelpApi();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
    }

    public void UserShareMedicalHelpApi() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Exception cart) {
            cart.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_REGISTER_MEDICAL_MESSAGE_BY_USERID);
        Log.e("servicename",Constants.USER_REGISTER_MEDICAL_MESSAGE_BY_USERID);

        asyncHttpClient.post(null, Constants.APP_REGISTER_MEDICAL_MESSAGE_BY_USERID_API, null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("MedicalResponse", Response);

                Log.v("Medical_Status_code", statusCode+"");

                if (statusCode==201) {

                    Toast.makeText(MainActivity.this, "Medical Help Emergency Message Shared Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else {

                    Toast.makeText(MainActivity.this, "Medical Help Emergency Message Share Not Successfull", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Medical_Error",error.toString());
                Log.e("Medical_Errorstatus", String.valueOf(statusCode));

            }

        });


    }


////////////Community_Watch............

    private void CommunityWatch() throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        View locationDialog = li.inflate(R.layout.dialog_share_location, null);


        //Initizliaing confirm button fo dialog box and edittext of dialog box
        TextView textmsg=(TextView)locationDialog.findViewById(R.id.textmsg);
        textmsg.setText("Do You Want To Share Community Watch Message To Your Sentinels ?");
        buttonYes = (TextView) locationDialog.findViewById(R.id.buttonYes);
        buttonCancel=(TextView)locationDialog.findViewById(R.id.buttonCancel);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(locationDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();


        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserShareCommunityWatchApi();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
    }

    public void UserShareCommunityWatchApi() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Exception cart) {
            cart.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_REGISTER_COMMUNITY_MESSAGE_BY_USERID);
        Log.e("servicename",Constants.USER_REGISTER_COMMUNITY_MESSAGE_BY_USERID);


        asyncHttpClient.post(null, Constants.APP_REGISTER_COMMUNITY_MESSAGE_BY_USERID_API, null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("CommunityResponse", Response);

                Log.v("Community_Status_code", statusCode+"");

                if (statusCode==201) {

                    Toast.makeText(MainActivity.this, "Community Watch Message Shared Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else {

                    Toast.makeText(MainActivity.this, "Community Watch Message Share Not Successfull", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Community_Error",error.toString());
                Log.e("Community_Errorstatus", String.valueOf(statusCode));

            }

        });


    }



    ////////////////////////////For Update Location.....................


    public void LocationApiCall() {

        Log.e("pc out uid",sharedPreferences.getString("userid", ""));

        JSONObject jObject = new JSONObject();
        try {

            Log.e("pc uid",sharedPreferences.getString("userid", ""));

            jObject.put("userId",sharedPreferences.getString("userid", ""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");

            jObject.put("gLatitude",latitude);
            Constants.USER_LATITUDE= String.valueOf(latitude);

            jObject.put("gLongitude",longitude);
            Constants.USER_LONGITUDE= String.valueOf(longitude);

            jObject.put("country",country_name);
            Constants.USER_COUNTRY=country_name;

            JSONObject updatedby = new JSONObject();
            updatedby.put("userId", sharedPreferences.getString("userid",""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");
            jObject.put("updatedBy",updatedby);

        } catch (Exception e) {
            e.printStackTrace();
        }

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("PermissionCheckObject", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SHOW_LOCATION);
        Log.e("servicename",Constants.SHOW_LOCATION);

        asyncHttpClient.put(null, Constants.APP_LOCATION_UPDATE_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("OTP_Response", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==200) {

                    try {
                        JSONObject job = new JSONObject(Response);
                        JSONObject updateby = job.getJSONObject("updatedBy");

                        es.putString(Constants.USER_ID, job.getString("userId"));
                        es.putString("lat", job.getString("gLatitude"));
                        es.putString("longi", job.getString("gLongitude"));
                        es.putString("country", job.getString("country"));
                        es.putString(Constants.USER_ID, updateby.getString("userId"));

                        es.commit();

                        //Log.d("UserId", Constants.USER_ID);
                        Log.d("LAT", Constants.USER_LATITUDE);
                        Log.d("LONGI", Constants.USER_LONGITUDE);
                        Log.d("COUNTRY", Constants.USER_COUNTRY);
                        //Log.d("updatedBYE", Constants.USER_ID);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    //Toast.makeText(PermissionCheck.this, "Location not submitted", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

            }
        });

    }



}
