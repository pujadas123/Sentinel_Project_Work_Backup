package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Adapters.SlidingImage_Adapter;
import com.example.exuberandroid.sentinel_module.R;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView;
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig;

public class TutorialActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    private ImageView shield_img, msg_img, location_img, community_img, medical_img;

    private static final String SHOWCASE_ID = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutorial_activity);

        init();
        MaterialShowcaseView.resetSingleUse(this,SHOWCASE_ID);
        presentShowcaseSequence();

    }


    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Focus Tutorial");
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);


        shield_img = (ImageView) findViewById(R.id.shield_img);


        msg_img = (ImageView) findViewById(R.id.msg_img);

        location_img = (ImageView) findViewById(R.id.location_img);

        community_img = (ImageView) findViewById(R.id.community_img);

        medical_img = (ImageView) findViewById(R.id.medical_img);

    }


    private void presentShowcaseSequence() {

        ShowcaseConfig config=new ShowcaseConfig();
        config.setDelay(500);


        //config.setMaskColor(R.color.today);

        MaterialShowcaseSequence sequence=new MaterialShowcaseSequence(this, SHOWCASE_ID);

        sequence.setConfig(config);

        sequence.addSequenceItem(shield_img, "The Safeguard Shield is the primary means of safety. In emergency situations, most times, you cannot do anything– this feature uses your preparedness beforehand and leverages that during crisis.", "GOT IT");
        sequence.addSequenceItem(msg_img, "Panic Button lets you alert your Sentinels with no delay. It is a more serious alert, which indicates grave danger.", "GOT IT");
        sequence.addSequenceItem(community_img, "Alert Sentinels around you requesting immediate aid. As more people use the app, your Sentinel safety net gets bigger.", "GOT IT");
        sequence.addSequenceItem(medical_img, "Contact Sentinels quickly during Medical emergencies and give them access to basic health information. Please complete profile with information.", "GOT IT");
        sequence.addSequenceItem(location_img, "Send a tracking link to your Sentinels. Let them watch over you for a certain time period.", "GOT IT");
        sequence.start();




    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        finish();
    }
}