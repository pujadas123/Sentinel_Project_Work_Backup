package com.example.exuberandroid.sentinel_module.Utils;

import com.example.exuberandroid.sentinel_module.Models.AlarmNewModel.AlarmModel;
import com.example.exuberandroid.sentinel_module.Models.alarmretromodel.AlarmOutput;
import com.example.exuberandroid.sentinel_module.Models.imageupload.UploadImageOutput;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;

public interface Api {

    //Multipart - Upload Image
    @Multipart
    @POST("/Admin/UploadProfilepic/")
    Call<UploadImageOutput> uploadImage(@Part MultipartBody.Part file,
                                        @Part("userId") RequestBody userId);




    String BASE_URL="http://sentinel.ap-south-1.elasticbeanstalk.com";


    @PUT("/Admin/UpdateFalseAlarmCode/")
    Call<AlarmOutput> AlarmInfo(@Header("accept") String accept,
                                @Header("auth-token") String token,
                                @Header("user-id") String userid,
                                @Header("role-id") String roleid,
                                @Header("service") String servicename,
                                @Body AlarmModel alarmModel);

}
