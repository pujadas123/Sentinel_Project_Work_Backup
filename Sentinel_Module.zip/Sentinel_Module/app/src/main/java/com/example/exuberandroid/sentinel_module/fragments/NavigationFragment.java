package com.example.exuberandroid.sentinel_module.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Activities.AboutUsActivity;
import com.example.exuberandroid.sentinel_module.Activities.EmergencyContactsActivity;
import com.example.exuberandroid.sentinel_module.Activities.MessageTemplateActivity;
import com.example.exuberandroid.sentinel_module.Activities.PrivacyPolicyActivity;
import com.example.exuberandroid.sentinel_module.Activities.ProfileActivity;
import com.example.exuberandroid.sentinel_module.Adapters.DrawerAdapter;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;

public class NavigationFragment extends Fragment {

    private ListView listView;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private View containerView, view;
    private DrawerAdapter drawerAdapter;
    private Intent intent;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;
    private Context context;
    private TextView tvName;
    private LinearLayout llHeader;
    private ImageView profilePicIV;

    String UserName;

    @Override
    public void onResume() {
        super.onResume();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_navigation, null);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context = getActivity();

        sharedPreferences=context.getApplicationContext().getSharedPreferences("PREF",0);
        es=sharedPreferences.edit();

        listView = (ListView) view.findViewById(R.id.listview_navigation_drawer);
        profilePicIV = (ImageView) view.findViewById(R.id.profilePicIV);
        drawerAdapter = new DrawerAdapter(view.getContext());
        listView.setAdapter(drawerAdapter);

        tvName=(TextView)view.findViewById(R.id.tv_name);
        tvName.setText(sharedPreferences.getString("name", ""));


        llHeader = (LinearLayout) view.findViewById(R.id.ll_header);
        /*llHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });*/


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 0);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 0);
                            }
                        } else {

                            intent = new Intent(view.getContext(), ProfileActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*/
                        intent = new Intent(view.getContext(), ProfileActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        break;
                    case 1:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 1);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 1);
                            }
                        } else {

                            intent = new Intent(view.getContext(), AboutUsActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*/
                        intent = new Intent(view.getContext(), AboutUsActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        break;
                    case 2:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 2);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 2);
                            }
                        } else {

                            intent = new Intent(view.getContext(), EmergencyContactsActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*/
                        intent = new Intent(view.getContext(), EmergencyContactsActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        break;
                    case 3:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            }
                        } else {

                            intent = new Intent(view.getContext(), MessageTemplateActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*/
                        intent = new Intent(view.getContext(), MessageTemplateActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        break;
                    case 4:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            }
                        } else {

                            intent = new Intent(view.getContext(), SettingsActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*/
                        intent = new Intent(view.getContext(), PrivacyPolicyActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        break;
                    /*case 5:
                        *//*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            } else {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                            }
                        } else {

                            intent = new Intent(view.getContext(), HelpActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }*//*
                        intent = new Intent(view.getContext(), HelpActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        break;*/
                    /*case 6:

                        *//*SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.clear();
                        editor.apply();
                        Intent intent = new Intent(context, LoginActivity.class);
                        startActivity(intent);
                        ((MainActivity) context).finish();*//*

                        sharedPreferences = context.getSharedPreferences("PREF", 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intent=new Intent(context,LoginActivity.class);
                        startActivity(intent);

                        break;*/
                    case 5:
                        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_CONTACTS)) {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                        } else {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA}, 3);
                        }
                        } else {

                        intent = new Intent(view.getContext(), SettingsActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        }*/

                        shareApp();

                    break;
                }
            }
        });


    }

    public void shareApp() {

        final String appName = getContext().getPackageName();

        String sharedMessage = "Sentinel App," +
                "\n" + "It is highly recommended that you download the app for best user experience and tracking services. You\n" +
                "can download the app here :- " + "market://details?id="
                + appName;
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Sentinel App");
        sharingIntent.putExtra(Intent.EXTRA_TEXT, sharedMessage );
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    public void setUp(int navFragment, DrawerLayout drawerLayout, final Toolbar toolbar) {
        containerView = getView().findViewById(navFragment);
        mDrawerLayout = drawerLayout;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 0) {
            /*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");
                intent = new Intent(view.getContext(), ProfileActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);*/
            intent = new Intent(view.getContext(), ProfileActivity.class);
            startActivity(intent);

            }
         else if (requestCode == 1) {
            /*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");

                intent = new Intent(view.getContext(), AboutUsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }*/
            intent = new Intent(view.getContext(), AboutUsActivity.class);
            startActivity(intent);

        }
        else if (requestCode == 2) {
            /*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");

                intent = new Intent(view.getContext(), EmergencyContactsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }*/
            intent = new Intent(view.getContext(), EmergencyContactsActivity.class);
            startActivity(intent);

        }
        else if (requestCode == 3) {
            /*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");

                intent = new Intent(view.getContext(), MessageTemplateActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                }*/
            intent = new Intent(view.getContext(), MessageTemplateActivity.class);
            startActivity(intent);

        }else if (requestCode == 4) {
            /*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");

                intent = new Intent(view.getContext(), PrivacyPolicyActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                }*/
            intent = new Intent(view.getContext(), PrivacyPolicyActivity.class);
            startActivity(intent);

        }/*else if (requestCode == 5) {
            *//*if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utilities.showToast(getActivity(), "Permission granted");

                intent = new Intent(view.getContext(), HelpActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);


            }*//*
            intent = new Intent(view.getContext(), HelpActivity.class);
            startActivity(intent);

        }*/else {
                 Utilities.showToast(getActivity(), "Please allow permission");

             }
    }
}