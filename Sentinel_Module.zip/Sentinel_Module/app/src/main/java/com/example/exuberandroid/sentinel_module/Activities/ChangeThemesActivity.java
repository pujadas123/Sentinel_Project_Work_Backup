package com.example.exuberandroid.sentinel_module.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;

public class ChangeThemesActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    RadioButton radio1, radio2, radio3, radio4, radio5;
    String selectedtemp;
    TextView UpdateBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_themes);

        init();
    }

    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Change Themes");


        radio1=(RadioButton)findViewById(R.id.radio1);
        radio2=(RadioButton)findViewById(R.id.radio2);
        radio3=(RadioButton)findViewById(R.id.radio3);
        radio4=(RadioButton)findViewById(R.id.radio4);
        radio5=(RadioButton)findViewById(R.id.radio5);

        UpdateBTN=(TextView)findViewById(R.id.UpdateBTN);
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);

        UpdateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (radio1.isChecked()) {
                    selectedtemp = radio1.getText().toString();
                }
                else if (radio2.isChecked()) {
                    selectedtemp = radio2.getText().toString();
                }
                else if (radio3.isChecked()) {
                    selectedtemp = radio3.getText().toString();
                }
                else if (radio4.isChecked()) {
                    selectedtemp = radio4.getText().toString();
                }
                else if (radio5.isChecked()) {
                    selectedtemp = radio5.getText().toString();
                }
                Toast.makeText(getApplicationContext(), "Themes Updated Successfully", Toast.LENGTH_LONG).show();
            }
        });
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
