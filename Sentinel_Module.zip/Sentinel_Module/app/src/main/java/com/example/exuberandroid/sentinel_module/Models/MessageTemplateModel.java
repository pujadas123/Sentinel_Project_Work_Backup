package com.example.exuberandroid.sentinel_module.Models;

public class MessageTemplateModel {

    String emergencyTypeId,emergency,messageTemplateId,message;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    boolean isSelected;


    public MessageTemplateModel() {

    }

    public MessageTemplateModel(String emergencyTypeId, String emergency, String messageTemplateId, String message) {
        this.emergencyTypeId = emergencyTypeId;
        this.emergency = emergency;
        this.messageTemplateId = messageTemplateId;
        this.message = message;
    }


    public String getEmergencyTypeId() {
        return emergencyTypeId;
    }

    public void setEmergencyTypeId(String emergencyTypeId) {
        this.emergencyTypeId = emergencyTypeId;
    }

    public String getEmergency() {
        return emergency;
    }

    public void setEmergency(String emergency) {
        this.emergency = emergency;
    }

    public String getMessageTemplateId() {
        return messageTemplateId;
    }

    public void setMessageTemplateId(String messageTemplateId) {
        this.messageTemplateId = messageTemplateId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
