package com.example.exuberandroid.sentinel_module.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    EditText input_email,input_phn;
    TextView loginBTN,txtmsg,txtforgotpwd;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;
    String uemail,uPhno,Status, ErrorStatus;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

//////////////////////
        sharedPreferences=getApplicationContext().getSharedPreferences("PREF",0);
        es=sharedPreferences.edit();
        es.apply();

        if (sharedPreferences.getString("isLoggedIn", "").equals("AUTHORISED")) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));

        }
///////////////////////////////

        init();

    }


    public void init(){

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
        input_email=(EditText)findViewById(R.id.input_email);
        input_email.addTextChangedListener(this);

        input_phn=(EditText)findViewById(R.id.input_phn);
        input_phn.addTextChangedListener(this);

        loginBTN=(TextView)findViewById(R.id.loginBTN);
        loginBTN.setOnClickListener(this);

        txtmsg=(TextView)findViewById(R.id.txtmsg);
        txtmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this,SignupActivity.class);
                startActivity(intent);
            }
        });

        txtforgotpwd=(TextView)findViewById(R.id.txtforgotpwd);
        txtforgotpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this,ForgotCredentialsActivity.class);
                startActivity(intent);
            }
        });

    }



    // validating email id
    public boolean isEmailValid(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }



    public void Logincall(JSONObject jObject) {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("Object", String.valueOf(jObject));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        asyncHttpClient.post(null, Constants.APP_LOGIN_API , entity, "application/json", new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(LoginActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("Response", Response);

                if (statusCode==200) {

                    try {

                        JSONObject job = new JSONObject(Response);
                        JSONObject jObj = job.getJSONObject("data");
                        JSONObject accessTokenObj = jObj.getJSONObject("accessId");
                        JSONObject roleId=jObj.getJSONObject("roleId");

                        es.putString("email", jObj.getString("userEmail"));
                        es.putString("phno", jObj.getString("phoneNumber"));


                        uemail = jObj.getString("userEmail");
                        uPhno = jObj.getString("phoneNumber");
                        Status = jObj.getString("verification");


                        //Constants.FALSE_ALARM=jObj.getString("falseAlarm");
                        es.putString("alarm", jObj.getString("falseAlarm"));
                        es.putString("name",jObj.getString("userName"));


                        //////

                        es.putString("userid",jObj.getString("userId"));
                        es.putString("userkey",jObj.getString("userKey"));
                        es.putString("tokenid",accessTokenObj.getString("accessTokenId"));
                        es.putString("roleid",roleId.getString("id"));

                        es.commit();
                        ///////

                        Log.d("EmailId", uemail);
                        Log.d("PhNo", uPhno);
                        Log.d("Response", Status);



                        if (Status.equals("AUTHORISED")) {
                            es.putString("isLoggedIn", "AUTHORISED");
                            es.commit();
                            Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            Intent in = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(in);


                        }
                        pd.dismiss();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    Toast.makeText(LoginActivity.this, "ErrorMsg", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                String Response = new String(responseBody);
                Log.e("Failure","fail");

                if (statusCode==400){
                    try {
                        JSONObject object=new JSONObject(Response);
                        ErrorStatus=object.getString("field1");
                        pd.dismiss();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(LoginActivity.this, "No User Exists With This Email", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    //Toast.makeText(LoginActivity.this, "No User Exists with this email", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }




    @Override
    public void onClick(View view) {
        if (Utilities.isOnline(this)) {


            if (!isEmailValid(input_email.getText().toString().trim())) {
                input_email.setError("Invalid Email");
            }
            if (input_email.getText().toString().length() == 0) {
                input_email.setError("Please Enter Your Email");
            } else {
                input_email.setError(null);
            }
            if (input_phn.getText().toString().length() == 0) {
                input_phn.setError("Please Enter Your Mobile No");
            }
            if (input_phn.getText().toString().trim().length() > 12){
                input_phn.setError("Please Enter a Valid Mobile No");
            }
            if (input_phn.getText().toString().trim().length() < 7){
                input_phn.setError("Please Enter a Valid Mobile No");
            }
            else {
                input_phn.setError(null);

                try {
                    JSONObject jObject = new JSONObject();
                    jObject.put("userEmail", input_email.getText().toString().trim());
                    uemail = URLEncoder.encode(input_email.getText().toString(), "UTF-8");

                    jObject.put("phoneNumber", input_phn.getText().toString().trim());
                    uPhno = URLEncoder.encode(input_phn.getText().toString(), "UTF-8");

                    Logincall(jObject);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }




        } else {
            Utilities.showNoConnectionToast(this);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        if (input_email.getText().toString().length() > 0) {
            input_email.setError(null);
        }
        if (input_phn.getText().toString().length() > 0) {
            input_phn.setError(null);
        }
    }


    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
