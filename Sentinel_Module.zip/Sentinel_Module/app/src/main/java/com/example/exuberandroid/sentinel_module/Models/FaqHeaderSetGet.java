package com.example.exuberandroid.sentinel_module.Models;

import java.util.ArrayList;

public class FaqHeaderSetGet {
    String hname;
    ArrayList<FaqChildSetGet> cArrayList;

    public String getHname() {
        return hname;
    }

    public void setHname(String hname) {
        this.hname = hname;
    }

    public ArrayList<FaqChildSetGet> getcArrayList() {
        return cArrayList;
    }

    public void setcArrayList(ArrayList<FaqChildSetGet> cArrayList) {
        this.cArrayList = cArrayList;
    }
}

