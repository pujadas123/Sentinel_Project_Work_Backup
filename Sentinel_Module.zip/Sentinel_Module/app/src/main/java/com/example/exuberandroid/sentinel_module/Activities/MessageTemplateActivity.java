package com.example.exuberandroid.sentinel_module.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Adapters.MessageTemplateAdapter;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateMainModel;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateModel;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class MessageTemplateActivity extends AppCompatActivity implements View.OnClickListener {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    String selectedtemp;
    TextView submitBTN;
    List<MessageTemplateModel> MsgTemp=new ArrayList<MessageTemplateModel>();
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;
    RecyclerView messageTemp;
    private MessageTemplateAdapter pAdapter;

    String messageTemplateId;

    private Snackbar snackbar;
    private View parentView;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_template);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();


        init();

        if (Utilities.isOnline(this)) {

            GetAllEmergencyContactsMsgTempByUser();

           // MessageTemplateApiCall(messageId, medicalMsgId, protectMsgId, locationMsgId, communityMsgId);

        }


    }


    private void init() {

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Message Template");
        parentView = findViewById(R.id.parent_layout);


        messageTemp = (RecyclerView) findViewById(R.id.messageTemp);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        messageTemp.setLayoutManager(mLayoutManager);
        messageTemp.hasFixedSize();

        submitBTN = (TextView) findViewById(R.id.submitBTN);
        submitBTN.setOnClickListener(this);
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /*public void showSnackBar() {
        snackbar = Snackbar.make(parentView, "Message Template Submited Successfully", Snackbar.LENGTH_INDEFINITE).setAction("Ok", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                snackbar.dismiss();
            }
        });
        snackbar.show();
    }*/

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void onClick(View view) {
        if (Utilities.isOnline(this)) {

            List<MessageTemplateMainModel> listFromAdapter = pAdapter.getTemplateList();

            for(int index = 0; index<listFromAdapter.size();index++)
            {
                List<MessageTemplateModel> adapterList = listFromAdapter.get(index).getMessageTemplateModelArrayList();

                for(int i = 0; i<adapterList.size();i++)
                {
                    if (adapterList.get(i).isSelected())
                    {
                        Log.e("id",adapterList.get(i).getMessageTemplateId());
                    }
                }

            }

            UpdateMessageTemplate();
        }

    }


    public void UpdateMessageTemplate() {

        JSONObject jsonObject = null;
            try {

                jsonObject = new JSONObject();

                jsonObject.put("userId", sharedPreferences.getString("userid", ""));
                Constants.USER_ID=sharedPreferences.getString("userid", "");



                JSONObject msgtempobj = new JSONObject();
                msgtempobj.put("messageTemplateId", messageTemplateId);


                JSONObject medicalMsgtempobj = new JSONObject();
                medicalMsgtempobj.put("messageTemplateId", messageTemplateId);

                JSONObject locationMsgtempobj  = new JSONObject();
                locationMsgtempobj.put("messageTemplateId", messageTemplateId);

                JSONObject protectMsgtempobj = new JSONObject();
                protectMsgtempobj.put("messageTemplateId", messageTemplateId);

                JSONObject communityMsgtempobj = new JSONObject();
                communityMsgtempobj.put("messageTemplateId", messageTemplateId);


            }
            catch (JSONException e) {
                e.printStackTrace();
            }


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jsonObject.toString());
            Log.d("UpdateObject", String.valueOf(jsonObject));
        } catch (Exception e) {
            e.printStackTrace();
        }

        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.USER_UPDATE_MESSAGE_TEMPLATE);
        Log.e("servicename",Constants.USER_UPDATE_MESSAGE_TEMPLATE);


        asyncHttpClient.put(null, Constants.APP_UPDATE_MESSAGE_TEMPLATE_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("MessageResponse", Response);

                Log.v("Status_code", statusCode+"");

                if (statusCode==200){


                    try {
                        JSONArray jsonArray=new JSONArray(Response);
                        for (int k=0; k<jsonArray.length(); k++) {
                            JSONObject object = jsonArray.getJSONObject(k);

                            JSONObject id = object.getJSONObject("userRefId");
                            es.putString(Constants.USER_ID, id.getString("userId"));

                            JSONObject msg = object.getJSONObject("messageTemplateId");
                            es.putString(messageTemplateId, msg.getString("messageTemplateId"));


                            Log.e("statuscode", String.valueOf(statusCode));

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();

                    }
                    Toast.makeText(MessageTemplateActivity.this, "Message Template Updated", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(MessageTemplateActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {

                    Toast.makeText(MessageTemplateActivity.this, "Message Template Not Updated", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Update_Error",error.toString());
                Log.e("Update_Errorstatus", String.valueOf(statusCode));

            }

        });


    }



    public void GetAllEmergencyContactsMsgTempByUser() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch(Exception e) {
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));
        Log.e("token",sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));
        Log.e("uid",sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));
        Log.e("rollid",sharedPreferences.getString("roleid",""));


        asyncHttpClient.addHeader("service", Constants.SHOW_EMERGENCY_CONTACT_MSG_TEMPLATE);
        Log.e("servicename",Constants.SHOW_EMERGENCY_CONTACT_MSG_TEMPLATE);


        asyncHttpClient.get(null, Constants.APP_GET_ALL_EMERGENCY_CONTACT_MESSAGETEMPLATE_API + sharedPreferences.getString("userid","") + "/",null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);

                if(statusCode == 200)
                {

                    Log.e("Response contact", Response);



                    try {
                        JSONArray jsonArray = new JSONArray(Response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            JSONObject msgtemplateId=jsonObject.getJSONObject("messageTemplateId");
                            JSONObject medicalMsgTempId=jsonObject.getJSONObject("medicalMessageTemplateId");
                            JSONObject locationMsgTempId=jsonObject.getJSONObject("locationMessageTemplateId");
                            JSONObject protectMsgTempId=jsonObject.getJSONObject("protectMessageTemplateId");
                            JSONObject communityMsgTempId=jsonObject.getJSONObject("communityMessageTemplateId");


                            String messageId=msgtemplateId.getString("messageTemplateId");
                            String medicalMsgId=medicalMsgTempId.getString("messageTemplateId");
                            String locationMsgId=locationMsgTempId.getString("messageTemplateId");
                            String protectMsgId=protectMsgTempId.getString("messageTemplateId");
                            String communityMsgId=communityMsgTempId.getString("messageTemplateId");


                            MessageTemplateApiCall(messageId,medicalMsgId,locationMsgId,protectMsgId,communityMsgId);


                        }
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }

                }





            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));

            }
        });


    }






    public void MessageTemplateApiCall(final String messageId, final String medicalMsgId,  final String locationMsgId,final String protectMsgId, final String communityMsgId) {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        }
        catch(Exception e) {
        }

        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SHOW_MESSAGE_TEMPLATE);
        Log.e("servicename",Constants.SHOW_MESSAGE_TEMPLATE);

        Log.e("messageId",messageId);
        Log.e("medicalMsgId",medicalMsgId);
        Log.e("protectMsgId",protectMsgId);
        Log.e("locationMsgId",locationMsgId);
        Log.e("communityMsgId",communityMsgId);



        asyncHttpClient.get(null, Constants.APP_MESSAGE_TEMPLATE_API , null, "application/json", new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(MessageTemplateActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("Response", Response);

                if (statusCode==200) {

                    try {

                        JSONArray jsonArray = new JSONArray(Response);

                        ArrayList<MessageTemplateModel> generalMessageList = new ArrayList<>();
                        ArrayList<MessageTemplateModel> medicalMessageList = new ArrayList<>();
                        ArrayList<MessageTemplateModel> locationShareMessageList = new ArrayList<>();
                        ArrayList<MessageTemplateModel> protectMessageList = new ArrayList<>();
                        ArrayList<MessageTemplateModel> communityMessageList = new ArrayList<>();


                        String generalMessageHeader = "";
                        String medicalMessageHeader = "";
                        String locationShareMessageHeader = "";
                        String protectMessageHeader = "";
                        String communityMessageHeader = "";


                        for (int i = 0; i < jsonArray.length(); i++) {



                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            JSONObject objectType = jsonObject.getJSONObject("emergencyTypeId");
                            String typeId = objectType.getString("emergencyTypeId");

                            if (typeId.equals("1"))
                            {

                                generalMessageHeader = objectType.getString("emergency");
                                String templateId = jsonObject.getString("messageTemplateId");
                                String templateMessage = jsonObject.getString("message");

                                MessageTemplateModel messageTemplateModel = new MessageTemplateModel();
                                messageTemplateModel.setMessage(templateMessage);
                                messageTemplateModel.setEmergencyTypeId(typeId);
                                messageTemplateModel.setMessageTemplateId(templateId);
                                messageTemplateModel.setEmergency(generalMessageHeader);

                                if(templateId.equals(messageId))
                                {
                                    messageTemplateModel.setSelected(true);
                                }



                                generalMessageList.add(messageTemplateModel);
                            }

                            if (typeId.equals("2"))
                            {

                                medicalMessageHeader = objectType.getString("emergency");
                                String templateId = jsonObject.getString("messageTemplateId");
                                String templateMessage = jsonObject.getString("message");

                                MessageTemplateModel messageTemplateModel = new MessageTemplateModel();
                                messageTemplateModel.setMessage(templateMessage);
                                messageTemplateModel.setEmergencyTypeId(typeId);
                                messageTemplateModel.setMessageTemplateId(templateId);
                                messageTemplateModel.setEmergency(medicalMessageHeader);

                                if(templateId.equals(medicalMsgId))
                                {
                                    messageTemplateModel.setSelected(true);
                                }

                                medicalMessageList.add(messageTemplateModel);
                            }

                            if (typeId.equals("3"))
                            {

                                locationShareMessageHeader = objectType.getString("emergency");
                                String templateId = jsonObject.getString("messageTemplateId");
                                String templateMessage = jsonObject.getString("message");

                                MessageTemplateModel messageTemplateModel = new MessageTemplateModel();
                                messageTemplateModel.setMessage(templateMessage);
                                messageTemplateModel.setEmergencyTypeId(typeId);
                                messageTemplateModel.setMessageTemplateId(templateId);
                                messageTemplateModel.setEmergency(locationShareMessageHeader);

                                Log.e("templateId",templateId);

                                if(templateId.equals(locationMsgId))
                                {
                                    messageTemplateModel.setSelected(true);

                                    Log.e("templateId","selected");
                                }


                                locationShareMessageList.add(messageTemplateModel);
                            }

                            if (typeId.equals("4"))
                            {

                                protectMessageHeader = objectType.getString("emergency");
                                String templateId = jsonObject.getString("messageTemplateId");
                                String templateMessage = jsonObject.getString("message");

                                MessageTemplateModel messageTemplateModel = new MessageTemplateModel();
                                messageTemplateModel.setMessage(templateMessage);
                                messageTemplateModel.setEmergencyTypeId(typeId);
                                messageTemplateModel.setMessageTemplateId(templateId);
                                messageTemplateModel.setEmergency(protectMessageHeader);

                                if(templateId.equals(protectMsgId))
                                {
                                    messageTemplateModel.setSelected(true);
                                }

                                protectMessageList.add(messageTemplateModel);
                            }


                            if (typeId.equals("5"))
                            {

                                communityMessageHeader = objectType.getString("emergency");
                                String templateId = jsonObject.getString("messageTemplateId");
                                String templateMessage = jsonObject.getString("message");

                                MessageTemplateModel messageTemplateModel = new MessageTemplateModel();
                                messageTemplateModel.setMessage(templateMessage);
                                messageTemplateModel.setEmergencyTypeId(typeId);
                                messageTemplateModel.setMessageTemplateId(templateId);
                                messageTemplateModel.setEmergency(communityMessageHeader);

                                if(templateId.equals(communityMsgId))
                                {
                                    messageTemplateModel.setSelected(true);
                                }

                                communityMessageList.add(messageTemplateModel);
                            }

                        }


                        MessageTemplateMainModel messageTemplateModelOne = new MessageTemplateMainModel();
                        messageTemplateModelOne.setMessageTemplateHeader(generalMessageHeader);
                        messageTemplateModelOne.setMessageTemplateModelArrayList(generalMessageList);

                        MessageTemplateMainModel messageTemplateModelTwo = new MessageTemplateMainModel();
                        messageTemplateModelTwo.setMessageTemplateHeader(medicalMessageHeader);
                        messageTemplateModelTwo.setMessageTemplateModelArrayList(medicalMessageList);

                        MessageTemplateMainModel messageTemplateModelThree = new MessageTemplateMainModel();
                        messageTemplateModelThree.setMessageTemplateHeader(locationShareMessageHeader);
                        messageTemplateModelThree.setMessageTemplateModelArrayList(locationShareMessageList);

                        MessageTemplateMainModel messageTemplateModelFour = new MessageTemplateMainModel();
                        messageTemplateModelFour.setMessageTemplateHeader(protectMessageHeader);
                        messageTemplateModelFour.setMessageTemplateModelArrayList(protectMessageList);


                        MessageTemplateMainModel messageTemplateModelFive = new MessageTemplateMainModel();
                        messageTemplateModelFive.setMessageTemplateHeader(communityMessageHeader);
                        messageTemplateModelFive.setMessageTemplateModelArrayList(communityMessageList);

                        ArrayList<MessageTemplateMainModel> adapterTemplateList = new ArrayList<>();
                        adapterTemplateList.add(messageTemplateModelOne);
                        adapterTemplateList.add(messageTemplateModelTwo);
                        adapterTemplateList.add(messageTemplateModelThree);
                        adapterTemplateList.add(messageTemplateModelFour);
                        adapterTemplateList.add(messageTemplateModelFive);





                        pAdapter = new MessageTemplateAdapter(MessageTemplateActivity.this, adapterTemplateList);
                        messageTemp.setAdapter(pAdapter);
                        pAdapter.notifyDataSetChanged();

                        pd.dismiss();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    Toast.makeText(MessageTemplateActivity.this, "Message Not Getting", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("ErrorMSG", String.valueOf(error));
                Log.e("ErrorStatusMessage", String.valueOf(statusCode));

            }
        });
    }
}
