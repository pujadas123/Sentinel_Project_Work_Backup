package com.example.exuberandroid.sentinel_module.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class FuturaLightTextView extends TextView {

    public FuturaLightTextView(Context context) {
        super(context);

        applyCustomFont(context);
    }

    public FuturaLightTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        applyCustomFont(context);
    }

    public FuturaLightTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        applyCustomFont(context);
    }

    private void applyCustomFont(Context context) {
        Typeface customFont = FontCache.getTypeface("futura_light.ttf", context);
        setTypeface(customFont);
    }
}
