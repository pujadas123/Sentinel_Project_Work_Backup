package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class ChangeFalseAlarmActivity extends AppCompatActivity implements View.OnClickListener {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    EditText oldFAN,newFAN,confFAN;
    TextView updateBTN;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_false_alarm);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();


        init();
    }

    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Change False Alarm No");


        oldFAN=(EditText) findViewById(R.id.oldFAN);
        oldFAN.setText(sharedPreferences.getString("alarm",""));

        Log.e("FalseAlarm", sharedPreferences.getString("alarm",""));

        newFAN=(EditText)findViewById(R.id.newFAN);
        confFAN=(EditText)findViewById(R.id.confFAN);

        updateBTN=(TextView)findViewById(R.id.updateBTN);
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
        updateBTN.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.updateBTN:

                if(newFAN.getText().toString().equalsIgnoreCase("")||confFAN.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(ChangeFalseAlarmActivity.this,"Please Fill All Fields", Toast.LENGTH_SHORT).show();

                }else if(newFAN.getText().toString().length()<1)

                {
                    Toast.makeText(ChangeFalseAlarmActivity.this,"Please Fill Minimum One Character", Toast.LENGTH_SHORT).show();

                }else if(newFAN.getText().toString().length()>4)

                {
                    Toast.makeText(ChangeFalseAlarmActivity.this,"Please Fill Between Four Character", Toast.LENGTH_SHORT).show();

                }else if(!newFAN.getText().toString().equalsIgnoreCase(confFAN.getText().toString()))
                {
                    Toast.makeText(ChangeFalseAlarmActivity.this,"New and Confirm False Alarm No Not Matched", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    SetFalseAlarmCall();
                    /*Toast.makeText(this, "False Alarm Code Updated Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(ChangeFalseAlarmActivity.this,SettingsActivity.class);
                    startActivity(intent);
                    finish();*/
                    //ChangePassword();

                }


                break;
        }
    }






    public void SetFalseAlarmCall() {

        JSONObject jObject = new JSONObject();
        try {

            jObject.put("userId",sharedPreferences.getString("userid", ""));
            Log.e("uid",sharedPreferences.getString("userid", ""));

            jObject.put("falseAlarm",newFAN.getText().toString().trim());
            Constants.FALSE_ALARM = newFAN.getText().toString();

            JSONObject updatedby = new JSONObject();
            updatedby.put("userId", sharedPreferences.getString("userid", ""));
            jObject.put("updatedBy",updatedby);
            Log.e("UpdatedBy",sharedPreferences.getString("userid", ""));

        } catch (Exception e) {
            e.printStackTrace();
        }

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("Object", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SET_FALSE_ALARM);
        Log.e("servicename",Constants.SET_FALSE_ALARM);

        asyncHttpClient.put(null, Constants.APP_SET_FALSE_AlARM_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("OTP_Response", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==200) {

                    try {
                        JSONObject job = new JSONObject(Response);
                        JSONObject updateby = job.getJSONObject("updatedBy");

                        es.putString(Constants.USER_ID,job.getString("userId"));
                        es.putString("alarm", job.getString("falseAlarm"));
                        es.putString(Constants.USER_ID,updateby.getString("userId"));

                        Log.d("UserId", Constants.USER_ID);
                        Log.d("false_Alarm", Constants.FALSE_ALARM);
                        Log.d("updatedBYE", Constants.USER_ID);

                        oldFAN.setText(sharedPreferences.getString("alarm",""));

                        es.commit();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(ChangeFalseAlarmActivity.this, "Alarm Updated Successfull", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(ChangeFalseAlarmActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(ChangeFalseAlarmActivity.this, "Alarm Not Set Successfull", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

            }
        });

    }

}
