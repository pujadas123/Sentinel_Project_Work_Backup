package com.example.exuberandroid.sentinel_module.Models;

import java.util.ArrayList;

public class HelpHeaderSet {
    String hname;
    ArrayList<HelpChildSetGet> cArrayList;

    public String getHname() {
        return hname;
    }

    public void setHname(String hname) {
        this.hname = hname;
    }

    public ArrayList<HelpChildSetGet> getcArrayList() {
        return cArrayList;
    }

    public void setcArrayList(ArrayList<HelpChildSetGet> cArrayList) {
        this.cArrayList = cArrayList;
    }
}

