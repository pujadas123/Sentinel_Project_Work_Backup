package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.R;

public class SettingsActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView toolbarTV;
    TextView tv_chang_alarm,tv_theme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        init();
    }

    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Settings");

        tv_chang_alarm=(TextView)findViewById(R.id.tv_chang_alarm);
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
        tv_chang_alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SettingsActivity.this,ChangeFalseAlarmActivity.class);
                startActivity(intent);
            }
        });
        tv_theme=(TextView)findViewById(R.id.tv_theme);
        tv_theme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SettingsActivity.this,ChangeThemesActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
