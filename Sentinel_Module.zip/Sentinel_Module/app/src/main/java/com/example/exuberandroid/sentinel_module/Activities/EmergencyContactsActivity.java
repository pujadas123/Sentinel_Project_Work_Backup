package com.example.exuberandroid.sentinel_module.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Models.SelectedContact;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.onegravity.contactpicker.ContactElement;
import com.onegravity.contactpicker.contact.Contact;
import com.onegravity.contactpicker.contact.ContactDescription;
import com.onegravity.contactpicker.contact.ContactSortOrder;
import com.onegravity.contactpicker.core.ContactPickerActivity;
import com.onegravity.contactpicker.group.Group;
import com.onegravity.contactpicker.picture.ContactPictureType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class EmergencyContactsActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private TextView toolbarTV;

    private static final String EXTRA_DARK_THEME = "EXTRA_DARK_THEME";
    private static final String EXTRA_GROUPS = "EXTRA_GROUPS";
    private static final String EXTRA_CONTACTS = "EXTRA_CONTACTS";

    private static final int REQUEST_CONTACT =10;

    private boolean mDarkTheme;
    private List<Contact> mContacts;
    private List<Group> mGroups;
    TextView contactsView;
    TextView updateBTN;
    SpannableStringBuilder result;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    String MessageTemplateId="7";
    /*String Lat="12.9716° N";
    String Longi="77.5946° E";
    String Country="INDIA";*/

    ArrayList<SelectedContact>Contact=new ArrayList<SelectedContact>();


    String ContactName;

    ProgressDialog pd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();
        // read parameters either from the Intent or from the Bundle
        if (savedInstanceState != null) {
            mDarkTheme = savedInstanceState.getBoolean(EXTRA_DARK_THEME);
            mGroups = (List<Group>) savedInstanceState.getSerializable(EXTRA_GROUPS);
            mContacts = (List<Contact>) savedInstanceState.getSerializable(EXTRA_CONTACTS);
        } else {
            Intent intent = getIntent();
            mDarkTheme = intent.getBooleanExtra(EXTRA_DARK_THEME, false);
            mGroups = (List<Group>) intent.getSerializableExtra(EXTRA_GROUPS);
            mContacts = (List<Contact>) intent.getSerializableExtra(EXTRA_CONTACTS);
        }

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);

        setTheme(mDarkTheme ? R.style.Theme_Dark : R.style.Theme_Light);

        setContentView(R.layout.activity_emergency_contacts);
        ImageButton button = (ImageButton) findViewById(R.id.pick_contact);
        updateBTN = (TextView) findViewById(R.id.updateBTN);
        contactsView = (TextView) findViewById(R.id.contacts);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        //toolbarTV.setText("Choose Contact");


        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(EmergencyContactsActivity.this, ContactPickerActivity.class)
                            .putExtra(ContactPickerActivity.EXTRA_THEME, mDarkTheme ? R.style.Theme_Dark : R.style.Theme_Light)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_BADGE_TYPE, ContactPictureType.ROUND.name())
                            .putExtra(ContactPickerActivity.EXTRA_SHOW_CHECK_ALL, true)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION, ContactDescription.ADDRESS.name())
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION_TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_SORT_ORDER, ContactSortOrder.AUTOMATIC.name());
                    startActivityForResult(intent, REQUEST_CONTACT);
                }
            });
        } else {
            finish();
        }


        updateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(contactsView !=null)
                {

                    Log.d("Line No", String.valueOf(contactsView.getLineCount()));
                    Log.d("Contact List",contactsView.getText().toString());
                    if (contactsView.getLineCount() > 1){

                        AddEmergencyContact();
                    }
                    else {
                        Toast.makeText(EmergencyContactsActivity.this, "Please pick at least 1 Sentinel", Toast.LENGTH_SHORT).show();
                    }


                }
                else {

                }
            }
        });

        ShowContactsByUser();


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean(EXTRA_DARK_THEME, mDarkTheme);
        if (mGroups != null) {
            outState.putSerializable(EXTRA_GROUPS, (Serializable) mGroups);
        }
        if (mContacts != null) {
            outState.putSerializable(EXTRA_CONTACTS, (Serializable) mContacts);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CONTACT && resultCode == Activity.RESULT_OK && data != null &&
                (data.hasExtra(ContactPickerActivity.RESULT_GROUP_DATA) ||
                        data.hasExtra(ContactPickerActivity.RESULT_CONTACT_DATA))) {

            // we got a result from the contact picker --> show the picked contacts
            mGroups = (List<Group>) data.getSerializableExtra(ContactPickerActivity.RESULT_GROUP_DATA);
            mContacts = (List<Contact>) data.getSerializableExtra(ContactPickerActivity.RESULT_CONTACT_DATA);
            populateContactList(mGroups, mContacts);
        }
    }


    private void populateContactList(List<Group> groups, List<Contact> contacts) {
        // we got a result from the contact picker --> show the picked contacts

        result = new SpannableStringBuilder();

        try {
            if (groups != null && ! groups.isEmpty()) {
                //result.append("GROUPS\n");
                for (Group group : groups) {
                    populateContact(result, group, "");
                    Contact.clear();
                    for (Contact contact : group.getContacts()) {
                        populateContact(result, contact, "    ");


                        SelectedContact selectedContact=new SelectedContact();
                        selectedContact.setContactName(contact.getDisplayName());
                        selectedContact.setContactNumber(contact.getPhone(0));
                        Contact.add(selectedContact);
                        Log.e("Contact", contact.getDisplayName());
                        Log.e("ContactNumber",  contact.getPhone(0));
                    }
                }
            }
            if (contacts != null && ! contacts.isEmpty()) {
                //result.append("CONTACTS\n");
                Contact.clear();
                for (Contact contact : contacts) {
                    populateContact(result, contact, "");

                    contact.getDisplayName();

                    SelectedContact selectedContact=new SelectedContact();
                    selectedContact.setContactName(contact.getDisplayName());
                    selectedContact.setContactNumber(contact.getPhone(0));
                    Contact.add(selectedContact);
                    Log.e("Contact", contact.getDisplayName());
                    Log.e("ContactNumber",  contact.getPhone(0));

                }
            }
        }
        catch (Exception e) {
            result.append(e.getMessage());
        }

        contactsView.setText(result);
    }

    private void populateContact(SpannableStringBuilder result, ContactElement element, String prefix) {
        //int start = result.length();

        String displayName = element.getDisplayName();

        result.append(prefix);
        result.append(displayName + "\n");
        //result.setSpan(new BulletSpan(15), start, result.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
    }



    public void AddEmergencyContact() {
        //create json array
        JSONArray jArray=new JSONArray();

        for (int i=0; i<Contact.size(); i++) {
            try {

                JSONObject jsonObject = new JSONObject();

                JSONObject uderidobj = new JSONObject();
                uderidobj.put("userId", sharedPreferences.getString("userid", ""));
                Constants.USER_ID=sharedPreferences.getString("userid", "");

                jsonObject.put("userRefId",uderidobj);

                JSONObject msgtempobi = new JSONObject();
                msgtempobi.put("messageTemplateId", MessageTemplateId);

                jsonObject.put("messageTemplateId",msgtempobi);

                jsonObject.put("phoneNumber",Contact.get(i).getContactNumber());
                jsonObject.put("contactName",Contact.get(i).getContactName());
                jsonObject.put("gLatitude",sharedPreferences.getString("lat",""));
                jsonObject.put("gLongititude",sharedPreferences.getString("longi",""));
                jsonObject.put("country",sharedPreferences.getString("country",""));

                JSONObject crebyobj = new JSONObject();
                crebyobj.put("userId", sharedPreferences.getString("userid", ""));
                Constants.USER_ID=sharedPreferences.getString("userid", "");

                jsonObject.put("createdBy",crebyobj);

                jArray.put(jsonObject);

            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jArray.toString());
            Log.d("Object", String.valueOf(jArray));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.ADD_CONTACT_SERVICE);
        Log.e("servicename",Constants.ADD_CONTACT_SERVICE);


        asyncHttpClient.post(null, Constants.APP_ADD_EMERGENCY_CONTACT_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("ContactResponse", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==201){


                    try {
                        JSONArray jsonArray=new JSONArray(Response);
                        for (int k=0; k<jsonArray.length(); k++) {
                            JSONObject object = jsonArray.getJSONObject(k);

                            JSONObject id = object.getJSONObject("userRefId");
                            es.putString(Constants.USER_ID, id.getString("userId"));

                            JSONObject msg = object.getJSONObject("messageTemplateId");
                            es.putString(MessageTemplateId, msg.getString("messageTemplateId"));

                            es.putString(Contact.get(k).getContactNumber(), object.getString("phoneNumber"));
                            es.putString(Contact.get(k).getContactName(), object.getString("contactName"));
                            es.putString(Constants.USER_LATITUDE, object.getString("gLatitude"));
                            es.putString(Constants.USER_LONGITUDE, object.getString("gLongititude"));
                            es.putString(Constants.USER_COUNTRY, object.getString("country"));

                            JSONObject createdBy = object.getJSONObject("createdBy");
                            es.putString(Constants.USER_ID, createdBy.getString("userId"));
                            Log.e("statuscode", String.valueOf(statusCode));

                            es.commit();

                        }


                        Log.e("CONTACT_LATITUDE",Constants.USER_LATITUDE);
                        Log.e("CONTACTS_LONGITUDE",Constants.USER_LONGITUDE);
                        Log.e("CONTACTS_COUNTRY",Constants.USER_COUNTRY);


                    } catch (JSONException e) {
                        e.printStackTrace();

                    }
                    Toast.makeText(EmergencyContactsActivity.this, "Emergency Contacts Successfully Updated", Toast.LENGTH_SHORT).show();
                    /*Intent intent=new Intent(EmergencyContactsActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();*/
                }
                else {

                    Toast.makeText(EmergencyContactsActivity.this, "Contact Not Submitted", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Toast.makeText(EmergencyContactsActivity.this, "Please pick at least 1 Sentinel", Toast.LENGTH_SHORT).show();

                Log.e("Error",error.toString());
                Log.e("Errorstatus", String.valueOf(statusCode));

            }

        });


    }




    public void ShowContactsByUser() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch(Exception e) {
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));
        Log.e("token",sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));
        Log.e("uid",sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));
        Log.e("rollid",sharedPreferences.getString("roleid",""));


        asyncHttpClient.addHeader("service", Constants.SHOW_CONTACT_BYUSER);
        Log.e("servicename",Constants.SHOW_CONTACT_BYUSER);


        asyncHttpClient.get(null, Constants.APP_SHOW_EMERGENCY_CONTACT_API + sharedPreferences.getString("userid","") + "/",null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(EmergencyContactsActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.e("Response contact", Response);

                if (Response == null)
                {
                    Log.d("Test","Hi....");
                }

                try {
                    JSONArray jsonArray=new JSONArray(Response);

                    StringBuilder sContact =   new StringBuilder("");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        sContact.append(jsonObject.getString("contactName"));
                        sContact.append("\n");

                    }
                    ContactName = sContact.toString();
                    contactsView.setText(ContactName);
                    Log.e("NAME", String.valueOf(ContactName));

                    Log.v("Update Status code", statusCode+"");

                    pd.dismiss();

                } catch (JSONException slide) {
                    slide.printStackTrace();
                }


                if (statusCode==200){
                    ShowContactsByUser2();
                }
                else {
                    Toast.makeText(EmergencyContactsActivity.this, "Contact List Not Updated", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));

            }
        });


    }


    public void ShowContactsByUser2() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch(Exception e) {
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SHOW_CONTACT_BYUSER);
        Log.e("servicename",Constants.SHOW_CONTACT_BYUSER);


        asyncHttpClient.get(null, Constants.APP_SHOW_EMERGENCY_CONTACT_API + sharedPreferences.getString("userid","") + "/",null, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);

                Log.d("Status", String.valueOf(statusCode));
                if (Response == null)
                {
                    Log.d("Test","Hi....");
                }
                Log.v("Response", Response);

                try {
                    JSONArray jsonArray=new JSONArray(Response);

                    StringBuilder sContact =   new StringBuilder("");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        sContact.append(jsonObject.getString("contactName"));
                        sContact.append("\n");

                    }
                    ContactName = sContact.toString();
                    contactsView.setText(ContactName);
                    Log.e("NAME", String.valueOf(ContactName));


                } catch (JSONException slide) {
                    slide.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));

            }
        });


    }



    @Override
    public void onBackPressed() {
        finish();
    }
}
